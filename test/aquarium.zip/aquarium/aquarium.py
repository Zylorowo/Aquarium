import pgzrun

# Größe des Aquariums
WIDTH = 800
HEIGHT = 500

# Unser erster Fisch
fish = Actor("fish", (100, 250))


def draw():
    # Hintergrund zeichnen
    screen.fill((10, 70, 120))
    # Fisch zeichnen
    fish.draw()


def update():
    # TODO 1: Bewege den Fisch nach rechts
    # TODO 2: Wenn der Fisch rechts aus dem Bild schwimmt, soll er links wieder auftauchen
    pass


pgzrun.go()
